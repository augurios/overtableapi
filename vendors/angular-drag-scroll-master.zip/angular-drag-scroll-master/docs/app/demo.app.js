(function () {
    'use strict';

    angular.module('DemoApp', [
        'ngRoute',

        'ng-drag-scroll'
    ]);

})();
